R4 safety-layer Monte Carlo — public evidence (2026-11-16)

Acceptance spec: docs/07-roadmap/first-public-release-safety-plan.md (R1, amendment 1).
Report:          docs/testing/R4-SAFETY-MC-20261116.md
Source revision: a9aeddbd706630808bf6a8985646c3075d673d27 (tag evidence/20261116-r4-safety-mc)

Contents
  pass1/seed-20261115, pass1/seed-20261116, pass2/seed-20261115, pass2/seed-20261116
      Four 16-run profile campaigns (r4-profile-v2, dualhost backend), as written by
      montecarlo.py, minus the executor binary (see below).
  m4-probe/       In-flight coordinator crash probe (fail-closed only; not a fault class).
  acceptance.log  Commands' results and exit codes recorded on host A.

Withheld file
  Each campaign's manifest.sha256 lists "executor". The binary is not published because
  it embeds absolute build paths of the operator's machine. Its SHA-256 is
  7207ccbd8c71a31a91b73c151e5cb2a7a1153f2f178c401b747bb1abae066a86 (environment.json,
  every run's metadata.json). Verify the remaining files with:
      sha256sum -c --ignore-missing manifest.sha256
  A full offline replay (montecarlo.py check) needs an executor with that digest.

Not claimed
  No probability, confidence, coverage, failure rate, independence, physical isolation,
  M4 recovery, Gate exit or production readiness. Safety-layer zero violations do not
  mean the whole system is safe.
