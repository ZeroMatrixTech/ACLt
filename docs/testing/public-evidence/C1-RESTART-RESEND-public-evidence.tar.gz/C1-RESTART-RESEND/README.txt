C1 restart and resend refusal: public evidence

Report:   docs/testing/C1-RESTART-RESEND-20261118.md
Source:   9aa998a0b7c847adfba1835896d00959b4af62f7 (evidence tag)
Scope:    guest-level runs on one physical host (QEMU TCG); no physical dual-host run

Contents
  restart/    drop reply, restart the serving process, resend the old frame, retry solves again
  duplicate/  drop reply, resend the old frame on the same serving process
  stale/      handoff after one accepted slot, then replay the pre-handoff solve and verify frames
  checks/     local suite, retained-evidence replay, guest run logs, R4 checks, summary
  commands.txt

Each scenario directory holds the coordinator and worker evidence roots (retained
frames, journal, publication, guest reports, dispatch and refusal logs), the serial
logs, the host result with the split observation summary, the host topology, and the
source pins.  The guest initramfs and the executor binary are not included: the
executor embeds the operator's build path, as in the R4 package.

Redaction
  Kernel image path and other local paths: replaced with <kernel> / <local-path>.
  Upstream kernel contact addresses in serial logs: replaced with <redacted-email>.
  No credentials, real host addresses or operator names are included.

Not claimed
  No failure rate, completion probability, cost or economic conclusion.
  The guests are not independent failure domains.  The reporting coordinator's
  authorization is still trusted, not verified by the serving boot.
